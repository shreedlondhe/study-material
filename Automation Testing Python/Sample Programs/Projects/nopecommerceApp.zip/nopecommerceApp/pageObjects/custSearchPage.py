class custSearchPage:
    textbox_email_id = "SearchEmail"
    textbox_firstname_id = "SearchFirstName"
    testbox_lastname_id = "SearchLastName"
    btn_search_id = "search-customers"

    / html / body / div[3] / div[1] / form[1] / section / div / div / div / div[2] / div / div[2] / div[1] / div / div / \
      div[1] / div / table