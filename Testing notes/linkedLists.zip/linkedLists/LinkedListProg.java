public class LinkedListProg {
    public static Node head;

    public static class Node {
        int data;
        Node next;

        Node(int d) {
            this.data = d;
            this.next = null;
        }
    }

    public static void addNewNode(Node newNode){
        if(head == null){
            head = newNode;
        }
        else {
            Node currenctNode = head;
            while (currenctNode.next!=null){
                currenctNode = currenctNode.next;
            }
            currenctNode.next = newNode;
        }
    }
    public static void printLinkedList(){
        if(head == null){
            System.out.println("Empty Linked List");
        }
        else {
            System.out.println("LinkedList :");
            Node currenctNode = head;
            while (currenctNode!=null){
                System.out.println(currenctNode.data);
                currenctNode = currenctNode.next;
            }
        }
    }
    public static void insertAtBegin(Node newNode){
        if(head == null){
            head = newNode;
        }
        else {
            Node temp = head;
            head = newNode;
            head.next = temp;
        }
    }
    public static void insertAfterNode(Node newNode, int value){
        if(head == null){
            head = newNode;
        }
        else {
            Node currentNode = head;
            while(currentNode.data!=value){
                currentNode = currentNode.next;
            }
            newNode.next = currentNode.next;
            currentNode.next = newNode;

        }
    }

    public static void deleteAtIndex(int index){
        if(head == null){
            System.out.println("No element a index");
        }
        else {
            int size = getListSize();
            if(index > size){
                System.out.println("Index Out of bound");
            }
            else {
                int currentIndex = 0;
                Node currentNode = head;
                while(currentNode!=null){
                    currentIndex++;
                    if(currentIndex==index){
                        break;
                    }
                    currentNode = currentNode.next;
                }
                currentNode.data = currentNode.next.data;
                currentNode.next = currentNode.next.next;
            }


        }
    }
    public static int getListSize(){
        if(head == null) {
            return 0;
        }else {
            int size = 0;
            Node currentNode = head;
            while(currentNode!=null){
                size++;
                currentNode = currentNode.next;
            }
            return size;
        }
    }
    public static void main(String[] args) {
        addNewNode(new Node(1));
        addNewNode(new Node(2));
        addNewNode(new Node(3));
        addNewNode(new Node(4));
        addNewNode(new Node(5));
        addNewNode(new Node(6));
        deleteAtIndex(6);
        printLinkedList();
    }
}

