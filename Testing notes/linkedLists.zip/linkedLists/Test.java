
class Test {

    public static void main(String[] args) {
        int[] height = new int[] { 1, 8, 6, 2, 5, 4, 8, 3, 7 };
        int lastElem = height[height.length - 1];
        int startIndex = -1;
        for (int i = 0; i < height.length - 2; i++) {
            if(height[i]>=lastElem){
                startIndex = i+1;
                break;
            }
        }
        
    }

}
