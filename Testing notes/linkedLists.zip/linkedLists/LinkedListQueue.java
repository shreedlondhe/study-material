public class LinkedListQueue {
    public static int rear = 0;
    public static int size = 5;
    public static Node front;

    public static class Node {
        int data;
        Node next;

        Node(int d) {
            this.data = d;
            this.next = null;
        }
    }

    public static boolean isQueueEmpty() {
        if (front == null) {
            System.out.println("Queue is Empty");
            return true;
        }
        return false;
    }

    public static boolean isQueueFull() {
        if (rear == size) {
            System.out.println("Queue is Full");
            return true;
        }
        return false;
    }

    public static void addElement(int element) {
        Node newNode = new Node(element);
        if (front == null) {
            front = newNode;
            rear++;
        } else if (!isQueueFull()) {
            Node currentNode = front;
            while (currentNode.next != null) {
                currentNode = currentNode.next;
            }
            currentNode.next = newNode;
            rear++;
        }
    }

    public static void deleteQueueElement() {
        if (!isQueueEmpty()) {
            front = front.next;
            rear --;
        }
    }

    public static void display() {
            Node currentNode = front;
            while (currentNode!= null) {
                System.out.print(currentNode.data+" ");
                currentNode = currentNode.next;
            }
            System.out.println();
        }

    public static void main(String[] args) {
        LinkedListQueue queueOp = new LinkedListQueue();
        queueOp.addElement(1);
        queueOp.addElement(2);
        queueOp.addElement(3);
        queueOp.addElement(4);
        queueOp.addElement(5);
        queueOp.display();
        queueOp.addElement(6);
        queueOp.deleteQueueElement();
        queueOp.deleteQueueElement();
        queueOp.deleteQueueElement();
        queueOp.deleteQueueElement();
        queueOp.deleteQueueElement();
        queueOp.deleteQueueElement();
        queueOp.display();

    }

}
