public class SearchNodeInTree {
    public static Node root;
    public static class Node {
        int value;
        Node left;
        Node right;

        Node(int v) {
            this.value = v;
            this.left = null;
            this.right = null;
        }
    }
    public static Node addReccursive(Node currentNode, int value){
        if(currentNode == null){
            return new Node(value);
        }
        if(value < currentNode.value){
            currentNode.left = addReccursive(currentNode.left,value);
        }else if(value>currentNode.value){
            currentNode.right = addReccursive(currentNode.right, value);
        }
        return currentNode;
    }
    
    public static boolean searchNode(Node currentNode, int value){
        if(currentNode == null){
            return false;
        }
        if(currentNode.value == value){
            return true;
        }
        else if(value < currentNode.value){
             return searchNode(currentNode.left,value);

        }else if(value>currentNode.value){
            return searchNode(currentNode.right, value);
        }
        return false;
    }
    public static void addItem(int value){
        root = addReccursive(root,value);
    }

    // //    10
    //      /  \
    // 

    public static Node deleteNode(Node node,int elem){
        if(node==null){
            return null;
        }
        if(elem < node.value){
            node.left = deleteNode(node.left,elem);
        }
        else if(elem > node.value){
            node.right = deleteNode(node.right,elem);
        }
        else{
            if(node.left== null){
                return node.right;
            }
            else if(node.right == null){
                return node.left;
            }
            node.value = getMinValue(node.right);
            node.right = deleteNode(node.right,elem);
        }
        return node;
        
    }
    public static int getMinValue(Node node){
        while(node.left!=null){
            node = node.left;
        }
        return node.value;
    }
    public static void deleteItem(int elem){
        root = deleteNode(root,elem);
    }
    public static void preOrderTree(Node node){
        if(node==null){
            return;
        }
        System.out.print(node.value +" ");
        preOrderTree(node.left);
        preOrderTree(node.right);
    }
    public static void inOrderTree(Node node){
        if(node==null){
            return;
        }
        
        inOrderTree(node.left);
        System.out.print(node.value +" ");
        inOrderTree(node.right);
    }

    public static void postOrderTree(Node node){
        if(node==null){
            return;
        }
        
        postOrderTree(node.left);
        postOrderTree(node.right);
        System.out.print(node.value +" ");

    }
    public static void main(String[] args) {
        SearchNodeInTree nodeInTree = new SearchNodeInTree();
        nodeInTree.addItem(10);
        nodeInTree.addItem(5);
        nodeInTree.addItem(60);
        nodeInTree.addItem(20);
        nodeInTree.addItem(80);
        nodeInTree.addItem(100);
        nodeInTree.addItem(70);
        nodeInTree.addItem(62);
        System.out.println("PreOrder travesal");
        preOrderTree(root);
        
        
    }
}