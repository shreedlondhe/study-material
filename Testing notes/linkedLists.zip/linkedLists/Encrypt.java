import java.util.ArrayList;

public class Encrypt {
    public static void main(String[] args) {
        ArrayList<String> arrayList = new ArrayList<>();

        // Add some strings to the ArrayList
        arrayList.add("P11");
        arrayList.add("Banana");
        arrayList.add("Cherry");
        arrayList.add("Date");

        // String to search for
        String searchString = "P1";

        // Check if the string is present in the ArrayList
        if (arrayList.contains(searchString)) {
            System.out.println(searchString + " is present in the ArrayList.");
        } else {
            System.out.println(searchString + " is not present in the ArrayList.");
        }
    }
}
