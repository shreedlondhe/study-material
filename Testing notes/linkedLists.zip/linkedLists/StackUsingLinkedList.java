public class StackUsingLinkedList {
    Node head;
    public static int size = 5;
    public static int top = 0;

    public static class Node {
        int data;
        Node next;

        Node(int d) {
            this.data = d;
            this.next = null;
        }
    }

    public static boolean isStackEmpty() {
        if (top == 0) {
            System.out.println("Stack is Empty");
            return true;
        }
        return false;
    }

    public static boolean isStackFull() {
        if (top == size) {
            System.out.println("Stack is Full");
            return true;
        }
        return false;
    }

    public void addNewElementInStack(int node) {
        if (!isStackFull()) {
            Node nodeToBeAdded = new Node(node);
            if (head == null) {
                head = nodeToBeAdded;
                top++;
            } else {
                Node currentNode = head;
                while (currentNode.next != null) {
                    currentNode = currentNode.next;
                }
                currentNode.next = nodeToBeAdded;
                top++;
            }
        }
    }

    public void deleteElementFromStack() {
        System.out.println("deleteElementFromStack");
        if (!isStackEmpty()) {
            System.out.println("isStackEmpty");
            if (top != 1) {
                Node currentNode = head;

                int index = 0;
                while (currentNode != null) {
                    index++;
                    if((index+1) == top){
                        currentNode.next = null;
                        top--;
                    }
                    currentNode = currentNode.next;
                }

            } else {
                head = null;
                top--;
            }
        }
    }

    public void printList() {
        Node currentNode = head;
        System.out.println("Linked List");
        while (currentNode != null) {
            System.out.println(currentNode.data);
            currentNode = currentNode.next;
        }
    }

    public static void main(String[] args) {
        StackUsingLinkedList stkLList = new StackUsingLinkedList();
        stkLList.addNewElementInStack(10);
        stkLList.deleteElementFromStack();
        stkLList.printList();
    }
}