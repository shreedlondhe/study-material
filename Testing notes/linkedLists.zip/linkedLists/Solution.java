/**
 * Solution
 */
public class Solution {

  public static void main(String[] args) {
    System.out.println("abc".substring(1));

    // Long calculatedSumAssured = (long) (217394 * 23);
    // Long nearest1 = (calculatedSumAssured / 1000000) * 1000000;
    //     Long nearest2 = nearest1 + 1000000;

    //     System.out.println("nearest1"+(long) (nearest1));
    //     System.out.println("nearest2"+(long) (nearest2));

    // System.out.println("Pratham"+(long) ((calculatedSumAssured - nearest1 > nearest2 - calculatedSumAssured)? nearest2 : nearest1));
    
  }
  
}
